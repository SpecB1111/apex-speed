import Foundation

enum SpeedUnit: String, Codable, CaseIterable, Identifiable {
    case kmh, mph
    var id: String { rawValue }
    var label: String { self == .kmh ? "km/h" : "mph" }
    var factor: Double { self == .kmh ? 3.6 : 2.2369362920544 }
    func display(_ metresPerSecond: Double) -> Double { metresPerSecond * factor }
}

struct SpeedTarget: Codable, Hashable, Identifiable {
    var value: Int
    var unit: SpeedUnit
    var id: String { "\(value)-\(unit.rawValue)" }
    var label: String { "0–\(value) \(unit.label)" }
    var speed: Double { Double(value) / unit.factor }
    static let defaults = [SpeedTarget(value: 60, unit: .mph),
                           SpeedTarget(value: 100, unit: .kmh),
                           SpeedTarget(value: 160, unit: .kmh)]
}

struct SpeedSample {
    var time: Date
    var speed: Double
    var horizontalAccuracy: Double
    var speedAccuracy: Double
    func usable(at now: Date) -> Bool {
        speed.isFinite && speed >= 0 && speed <= 150 &&
        horizontalAccuracy.isFinite && (0...25).contains(horizontalAccuracy) &&
        speedAccuracy.isFinite && (0...2).contains(speedAccuracy) &&
        (-0.5...3).contains(now.timeIntervalSince(time))
    }
    var suitableForTiming: Bool {
        speed.isFinite && (0...150).contains(speed) &&
        horizontalAccuracy.isFinite && (0...15).contains(horizontalAccuracy) &&
        speedAccuracy.isFinite && (0...1).contains(speedAccuracy)
    }
    func displayQuality(at now: Date) -> GPSQuality {
        guard speed.isFinite, (0...150).contains(speed),
              horizontalAccuracy.isFinite, (0...65).contains(horizontalAccuracy),
              speedAccuracy.isFinite, (0...4).contains(speedAccuracy),
              (-0.5...3).contains(now.timeIntervalSince(time)) else { return .unavailable }
        if suitableForTiming { return .strong }
        return usable(at: now) ? .fair : .limited
    }
}

enum GPSQuality: String {
    case strong, fair, limited, unavailable
    var label: String {
        switch self {
        case .strong: return "Strong GPS"
        case .fair: return "Fair GPS · smoothing"
        case .limited: return "Weak GPS · approximate speed"
        case .unavailable: return "Waiting for GPS"
        }
    }
    var responseTime: Double {
        switch self {
        case .strong: return 0.15
        case .fair: return 0.5
        case .limited: return 0.9
        case .unavailable: return 0
        }
    }
}

/// Display-only, time-aware low-pass filter. Never predicts speed or feeds timing/stats.
/// Weak fixes receive more smoothing; good reception restores a rapid response.
struct AdaptiveSpeedDisplay {
    private(set) var speed: Double?
    private var previousTime: Date?

    mutating func reset() { speed = nil; previousTime = nil }

    mutating func consume(_ sample: SpeedSample, at now: Date) -> Double? {
        if let previousTime, sample.time <= previousTime { return speed }
        let quality = sample.displayQuality(at: now)
        guard quality != .unavailable else { reset(); return nil }
        defer { self.previousTime = sample.time }
        guard let oldSpeed = speed, let previousTime,
              sample.time.timeIntervalSince(previousTime) <= 2.5 else {
            speed = sample.speed; return speed
        }
        // Strong stationary fixes should not leave a decaying non-zero speed on screen.
        if quality == .strong && sample.speed <= 0.5 {
            speed = sample.speed; return speed
        }
        let delta = sample.time.timeIntervalSince(previousTime)
        let weight = 1 - exp(-delta / quality.responseTime)
        speed = oldSpeed + weight * (sample.speed - oldSpeed)
        return speed
    }
}

struct Split: Codable, Identifiable {
    var target: SpeedTarget
    var seconds: Double
    var id: String { target.id }
}

struct AccelerationRun: Codable, Identifiable {
    var id = UUID()
    var started: Date
    var splits: [Split]
    var maxSampleGap: Double
    var worstSpeedAccuracy: Double
}

/// All calculations use unsmoothed SI values and sensor timestamps, never UI clocks.
struct AccelerationEngine {
    private(set) var phase = "Come to a complete stop"
    private(set) var splits: [Split] = []
    private var previous: SpeedSample?
    private var stationarySince: Date?
    private var lastStationary: Date?
    private var armed = false
    private var start: Date?
    private var maxGap = 0.0
    private var worstAccuracy = 0.0
    private let targets: [SpeedTarget]

    init(targets: [SpeedTarget]) {
        self.targets = Array(Set(targets)).filter { $0.value > 0 }.sorted { $0.speed < $1.speed }
    }

    mutating func invalidate(_ reason: String = "GPS interrupted · stop to re-arm") {
        previous = nil; stationarySince = nil; lastStationary = nil
        armed = false; start = nil; splits = []; maxGap = 0; worstAccuracy = 0
        phase = reason
    }

    mutating func finish() -> AccelerationRun? {
        defer { invalidate() }
        guard let start, !splits.isEmpty else { return nil }
        return AccelerationRun(started: start, splits: splits,
                               maxSampleGap: maxGap, worstSpeedAccuracy: worstAccuracy)
    }

    mutating func consume(_ sample: SpeedSample) -> AccelerationRun? {
        guard sample.suitableForTiming else {
            invalidate("GPS too weak for timing"); return nil
        }
        if let previous, sample.time <= previous.time { return nil }
        if let previous, sample.time.timeIntervalSince(previous.time) > 2.5 {
            invalidate()
        }
        let prior = previous
        previous = sample
        if let prior { maxGap = max(maxGap, sample.time.timeIntervalSince(prior.time)) }
        worstAccuracy = max(worstAccuracy, sample.speedAccuracy)

        if sample.speed <= 0.5 {
            stationarySince = stationarySince ?? sample.time
            lastStationary = sample.time
            if sample.time.timeIntervalSince(stationarySince!) >= 2 {
                let completed = finish()
                previous = sample; stationarySince = sample.time; lastStationary = sample.time
                armed = true; phase = "Armed · ready when you are"
                return completed
            }
        } else {
            stationarySince = nil
        }
        if start == nil, armed, sample.speed >= 1.5, let lastStationary {
            // Last observed stationary fix is the conservative launch estimate.
            // No rollout deduction and no hundredth-second accuracy claim.
            guard sample.time.timeIntervalSince(lastStationary) <= 5 else {
                invalidate("Slow launch · stop to re-arm"); return nil
            }
            start = lastStationary; armed = false; splits = []
            phase = "Timing acceleration"
        }
        guard let start, let prior else { return nil }
        if sample.time.timeIntervalSince(start) > 120 {
            let result = finish(); phase = "Run ended · stop to re-arm"; return result
        }
        for target in targets where !splits.contains(where: { $0.target.id == target.id }) {
            if prior.speed < target.speed && sample.speed >= target.speed {
                let fraction = (target.speed - prior.speed) / (sample.speed - prior.speed)
                let crossing = prior.time.addingTimeInterval(sample.time.timeIntervalSince(prior.time) * fraction)
                splits.append(Split(target: target, seconds: crossing.timeIntervalSince(start)))
            }
        }
        if !targets.isEmpty && splits.count == targets.count {
            let result = finish(); phase = "Run saved · stop to re-arm"; return result
        }
        return nil
    }
}

struct SessionRecord: Codable, Identifiable {
    var id = UUID()
    var started: Date
    var updated: Date
    var ended: Date?
    var distance = 0.0
    var measuredSeconds = 0.0
    var movingSeconds = 0.0
    var maxSpeed = 0.0
    var runs: [AccelerationRun] = []
    var interrupted = false
    var maxLeanLeft: Double?
    var maxLeanRight: Double?
    var averageSpeed: Double { measuredSeconds > 0 ? distance / measuredSeconds : 0 }
    var duration: Double { max(0, (ended ?? updated).timeIntervalSince(started)) }
}

struct MotionVector {
    var x: Double
    var y: Double
    var z: Double
    var length: Double { sqrt(dot(self)) }
    func dot(_ other: MotionVector) -> Double { x * other.x + y * other.y + z * other.z }
    func scaled(_ scale: Double) -> MotionVector { .init(x: x * scale, y: y * scale, z: z * scale) }
    func subtracting(_ other: MotionVector) -> MotionVector { .init(x: x - other.x, y: y - other.y, z: z - other.z) }
    var normalized: MotionVector? {
        let size = length
        guard size.isFinite, size > 0.001 else { return nil }
        return scaled(1 / size)
    }
}

/// Estimates lateral phone tilt from Core Motion's fused gravity vector.
/// Mount the phone in portrait, with its right edge aligned toward the bike's right.
/// Projecting gravity into the calibrated lateral plane rejects pure forward pitch.
struct LeanCalibration {
    let down: MotionVector
    let right: MotionVector
    init?(gravity: MotionVector) {
        guard let down = gravity.normalized else { return nil }
        let phoneRight = MotionVector(x: 1, y: 0, z: 0)
        let lateral = phoneRight.subtracting(down.scaled(phoneRight.dot(down)))
        guard lateral.length >= 0.25, let right = lateral.normalized else { return nil }
        self.down = down; self.right = right
    }
    func degrees(gravity: MotionVector) -> Double? {
        guard let direction = gravity.normalized else { return nil }
        let sideways = direction.dot(right)
        let vertical = direction.dot(down)
        guard hypot(sideways, vertical) >= 0.25 else { return nil }
        let degrees = atan2(sideways, vertical) * 180 / .pi
        return abs(degrees) <= 90 ? degrees : nil
    }
}

struct LeanZeroCapture {
    private var start: Double?
    private var previous: Double?
    private var anchor: MotionVector?
    private var sum = MotionVector(x: 0, y: 0, z: 0)
    private var count = 0
    private(set) var progress = 0.0
    mutating func reset() { self = LeanZeroCapture() }
    mutating func consume(time: Double, gravity: MotionVector, rotation: Double, acceleration: Double) -> LeanCalibration? {
        guard time.isFinite else { reset(); return nil }
        if let previous, time <= previous { return nil }
        guard rotation.isFinite, acceleration.isFinite, rotation >= 0, acceleration >= 0,
              rotation < 0.12, acceleration < 0.08, let direction = gravity.normalized else {
            reset(); return nil
        }
        if let previous, time - previous > 0.15 { reset() }
        if let anchor, direction.subtracting(anchor).length > 0.025 { reset() }
        if start == nil { start = time; anchor = direction }
        previous = time
        sum = .init(x: sum.x + direction.x, y: sum.y + direction.y, z: sum.z + direction.z)
        count += 1
        progress = min(1, (time - (start ?? time)) / 2)
        guard progress >= 1, count >= 20 else { return nil }
        return LeanCalibration(gravity: sum)
    }
}

struct TripAccumulator {
    private var previous: SpeedSample?
    mutating func breakContinuity() { previous = nil }
    mutating func consume(_ sample: SpeedSample, record: inout SessionRecord) {
        if let previous, sample.time <= previous.time { return }
        if let previous {
            let delta = sample.time.timeIntervalSince(previous.time)
            if delta <= 2.5 {
                let mean = (max(0, previous.speed) + max(0, sample.speed)) / 2
                record.distance += mean * delta
                record.measuredSeconds += delta
                if mean >= 0.5 { record.movingSeconds += delta }
            }
        }
        record.maxSpeed = max(record.maxSpeed, sample.speed)
        record.updated = sample.time
        previous = sample
    }
}
