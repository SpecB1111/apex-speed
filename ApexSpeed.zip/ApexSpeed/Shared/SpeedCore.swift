import Foundation

enum SpeedUnit: String, Codable, CaseIterable, Identifiable {
    case kmh, mph
    var id: String { rawValue }
    var label: String { self == .kmh ? "km/h" : "mph" }
    var factor: Double { self == .kmh ? 3.6 : 2.2369362920544 }
    func display(_ metresPerSecond: Double) -> Double { metresPerSecond * factor }
}

struct SpeedTarget: Codable, Hashable, Identifiable {
    var value: Int
    var unit: SpeedUnit
    var id: String { "\(value)-\(unit.rawValue)" }
    var label: String { "0–\(value) \(unit.label)" }
    var speed: Double { Double(value) / unit.factor }
    static let defaults = [SpeedTarget(value: 60, unit: .mph),
                           SpeedTarget(value: 100, unit: .kmh),
                           SpeedTarget(value: 160, unit: .kmh)]
}

struct SpeedSample {
    var time: Date
    var speed: Double
    var horizontalAccuracy: Double
    var speedAccuracy: Double
    func usable(at now: Date) -> Bool {
        speed.isFinite && speed >= 0 && speed <= 150 &&
        horizontalAccuracy.isFinite && (0...25).contains(horizontalAccuracy) &&
        speedAccuracy.isFinite && (0...2).contains(speedAccuracy) &&
        (-0.5...3).contains(now.timeIntervalSince(time))
    }
    var suitableForTiming: Bool { horizontalAccuracy <= 15 && speedAccuracy <= 1 }
}

struct Split: Codable, Identifiable {
    var target: SpeedTarget
    var seconds: Double
    var id: String { target.id }
}

struct AccelerationRun: Codable, Identifiable {
    var id = UUID()
    var started: Date
    var splits: [Split]
    var maxSampleGap: Double
    var worstSpeedAccuracy: Double
}

/// All calculations use unsmoothed SI values and sensor timestamps, never UI clocks.
struct AccelerationEngine {
    private(set) var phase = "Come to a complete stop"
    private(set) var splits: [Split] = []
    private var previous: SpeedSample?
    private var stationarySince: Date?
    private var lastStationary: Date?
    private var armed = false
    private var start: Date?
    private var maxGap = 0.0
    private var worstAccuracy = 0.0
    private let targets: [SpeedTarget]

    init(targets: [SpeedTarget]) {
        self.targets = Array(Set(targets)).filter { $0.value > 0 }.sorted { $0.speed < $1.speed }
    }

    mutating func invalidate(_ reason: String = "GPS interrupted · stop to re-arm") {
        previous = nil; stationarySince = nil; lastStationary = nil
        armed = false; start = nil; splits = []; maxGap = 0; worstAccuracy = 0
        phase = reason
    }

    mutating func finish() -> AccelerationRun? {
        defer { invalidate() }
        guard let start, !splits.isEmpty else { return nil }
        return AccelerationRun(started: start, splits: splits,
                               maxSampleGap: maxGap, worstSpeedAccuracy: worstAccuracy)
    }

    mutating func consume(_ sample: SpeedSample) -> AccelerationRun? {
        guard sample.suitableForTiming else {
            invalidate("GPS too weak for timing"); return nil
        }
        if let previous, sample.time <= previous.time { return nil }
        if let previous, sample.time.timeIntervalSince(previous.time) > 2.5 {
            invalidate()
        }
        let prior = previous
        previous = sample
        if let prior { maxGap = max(maxGap, sample.time.timeIntervalSince(prior.time)) }
        worstAccuracy = max(worstAccuracy, sample.speedAccuracy)

        if sample.speed <= 0.5 {
            stationarySince = stationarySince ?? sample.time
            lastStationary = sample.time
            if sample.time.timeIntervalSince(stationarySince!) >= 2 {
                let completed = finish()
                previous = sample; stationarySince = sample.time; lastStationary = sample.time
                armed = true; phase = "Armed · ready when you are"
                return completed
            }
        } else {
            stationarySince = nil
        }
        if start == nil, armed, sample.speed >= 1.5, let lastStationary {
            // Last observed stationary fix is the conservative launch estimate.
            // No rollout deduction and no hundredth-second accuracy claim.
            guard sample.time.timeIntervalSince(lastStationary) <= 5 else {
                invalidate("Slow launch · stop to re-arm"); return nil
            }
            start = lastStationary; armed = false; splits = []
            phase = "Timing acceleration"
        }
        guard let start, let prior else { return nil }
        if sample.time.timeIntervalSince(start) > 120 {
            let result = finish(); phase = "Run ended · stop to re-arm"; return result
        }
        for target in targets where !splits.contains(where: { $0.target.id == target.id }) {
            if prior.speed < target.speed && sample.speed >= target.speed {
                let fraction = (target.speed - prior.speed) / (sample.speed - prior.speed)
                let crossing = prior.time.addingTimeInterval(sample.time.timeIntervalSince(prior.time) * fraction)
                splits.append(Split(target: target, seconds: crossing.timeIntervalSince(start)))
            }
        }
        if !targets.isEmpty && splits.count == targets.count {
            let result = finish(); phase = "Run saved · stop to re-arm"; return result
        }
        return nil
    }
}

struct SessionRecord: Codable, Identifiable {
    var id = UUID()
    var started: Date
    var updated: Date
    var ended: Date?
    var distance = 0.0
    var measuredSeconds = 0.0
    var movingSeconds = 0.0
    var maxSpeed = 0.0
    var runs: [AccelerationRun] = []
    var interrupted = false
    var averageSpeed: Double { measuredSeconds > 0 ? distance / measuredSeconds : 0 }
    var duration: Double { max(0, (ended ?? updated).timeIntervalSince(started)) }
}

struct TripAccumulator {
    private var previous: SpeedSample?
    mutating func breakContinuity() { previous = nil }
    mutating func consume(_ sample: SpeedSample, record: inout SessionRecord) {
        if let previous, sample.time <= previous.time { return }
        if let previous {
            let delta = sample.time.timeIntervalSince(previous.time)
            if delta <= 2.5 {
                let mean = (max(0, previous.speed) + max(0, sample.speed)) / 2
                record.distance += mean * delta
                record.measuredSeconds += delta
                if mean >= 0.5 { record.movingSeconds += delta }
            }
        }
        record.maxSpeed = max(record.maxSpeed, sample.speed)
        record.updated = sample.time
        previous = sample
    }
}
