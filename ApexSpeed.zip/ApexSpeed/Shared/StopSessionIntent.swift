import AppIntents

struct StopSessionIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Stop Apex Speed session"
    static var description = IntentDescription("Stops GPS tracking, saves this session, and removes the Live Activity.")
    static var openAppWhenRun: Bool = false

    @MainActor
    func perform() async throws -> some IntentResult {
        #if !WIDGET_EXTENSION
        await TrackingStore.shared.stop()
        #endif
        return .result()
    }
}
