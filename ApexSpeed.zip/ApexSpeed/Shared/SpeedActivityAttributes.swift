import ActivityKit
import Foundation

struct SpeedActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var speed: Int?
        var unit: String
        var maxSpeed: Int
        var distance: String
        var status: String
        var updated: Date
    }
    var sessionID: UUID
    var started: Date
}
