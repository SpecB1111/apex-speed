# Apex Speed

A native SwiftUI GPS speedometer with an ActivityKit Dynamic Island / Lock Screen display, automatic acceleration estimates, and private on-device session history. iPhone, iOS 17 or later. No third-party dependencies, backend, account, or generated sensor data.

## Install on your iPhone

You need **a Mac with Xcode** and your Apple Account. Use a current Xcode release that supports the iOS version on your phone. This folder contains the actual `.xcodeproj`; no project generator is required.

1. Copy this entire folder to the Mac and open **ApexSpeed.xcodeproj**. Open the project, not `Package.swift` (the package is only for calculation tests).
2. In Xcode → Settings → Accounts, add your Apple Account.
3. Open `Config/Signing.xcconfig`. Change `APEX_BUNDLE_ID` from `com.yourname.ApexSpeed` to a unique identifier, such as `com.yourinitials.apexspeed.personal`. It configures both the app and the extension, whose identifier ends in `.LiveActivity`.
4. Select the project in the navigator. Under **both** targets, `ApexSpeed` and `ApexSpeedWidget`, select Signing & Capabilities → Automatically manage signing and choose the same Team. Alternatively, enter your Team ID in `Config/Signing.xcconfig`. Do not add an invented Live Activities entitlement: this project enables it through `NSSupportsLiveActivities` in the app’s Info.plist.
5. Connect and unlock the iPhone, trust the Mac, and select it as Xcode’s run destination. If prompted, enable **Settings → Privacy & Security → Developer Mode**, restart the phone, and confirm. If a developer trust prompt appears, use Settings → General → VPN & Device Management.
6. Select the **ApexSpeed** scheme and press **Run**. Xcode builds, signs, embeds the widget extension, and installs the app.
7. Open Apex Speed on the phone. While parked outdoors, tap Start Session, accept the closed-course notice, allow **While Using the App**, and leave **Precise Location** enabled. If the permission prompt interrupts starting, tap Start Session again.
8. Allow a good GPS fix. Leave the app normally to multitask. On a Dynamic Island iPhone, the Live Activity can show your speed. Hold the Island to expand it. Other supported iPhones get the Lock Screen presentation.
9. Tap **Stop & Save** in the app or **Stop** in the expanded Island / Lock Screen card to stop location updates, save the session, and dismiss the activity.

### Signing and Windows / 3uTools

A free Apple Account can use Xcode’s Personal Team for personal-device testing. Apple currently says these provisioning profiles expire after **7 days**, so rebuild and reinstall when they expire; Personal Team also has device and app limits. A paid Apple Developer Program membership is needed for TestFlight / App Store distribution. Follow the current signing options shown for your account. [Apple account and Personal Team requirements](https://developer.apple.com/help/account/basics/about-your-developer-account).

Windows and 3uTools do not compile this SwiftUI Xcode project. An installer does not replace Apple signing. There is no prebuilt IPA in this delivery because a signed device build requires a Mac/Xcode and your signing team. For an IPA, use Product → Archive in Xcode with a generic iOS device destination, then Organizer → Distribute App and choose the eligible distribution method for your account. Development or ad hoc exports must be provisioned for the receiving device; TestFlight uses App Store Connect. Do not install unknown enterprise certificates or share your Apple password with someone offering to sign it.

## Included features

- Animated dark dashboard with numeric speed transitions, a spring-animated speed arc, unit selection, and accessible controls. Reduced Motion disables the dashboard’s explicit spring animation.
- Raw Core Location speed; no app demo mode, mock feed, fabricated runs, or seeded history.
- Automatic 0–60 mph, 0–100 km/h, 0–160 km/h timing plus up to eight configurable targets.
- Last-run splits, personal bests, per-run quality information, maximum speed, integrated distance, measured/moving time, session duration, and average speed.
- Locally saved session history with deletion and interrupted-session checkpoint recovery.
- Background location updates during an explicitly started session. No Always Location permission, server push, audio keepalive, or automatic background restart.
- Live Activity with compact, minimal, expanded, and Lock Screen layouts; native Stop action; stale-reading fallback.

## What iOS permits

The GPS session can continue when you switch apps because the app uses the location background mode and starts updates in the foreground. The widget does not read GPS: the app supplies its content. **iOS controls when and how often the Island renders updates**; this is not a guaranteed real-time instrument. Activity updates are submitted at most once per second, but actual display cadence can be slower.

**Closing a tracking session is different from force-quitting the app.** The explicit Stop action ends both tracking and the Live Activity. Swiping the app away stops its execution and may leave the last Live Activity visible. Termination callbacks and async cleanup are not guaranteed. The activity carries a five-second stale date and shows a dash when iOS marks it stale; reopening the app removes orphan activities. Staleness does not itself dismiss the activity, and the transition’s timing is controlled by iOS.

Apple documents an eight-hour active lifetime, potentially followed by four hours on the Lock Screen. Apex stops a session at 7 hours 54 minutes when it has runtime; it cannot guarantee a background timer fires during suspension. Live Activities may be disabled or dismissed independently of tracking. Dismissing a card does not stop GPS: use Stop in the app or activity.

See [PLATFORM-NOTES.md](Docs/PLATFORM-NOTES.md) for dated Apple sources and [TESTING.md](Docs/TESTING.md) for the device acceptance checklist.

## Measurement rules

- Internal values are metres/second. Changing displayed units never changes target definitions.
- Speed requires a nonnegative fix, horizontal uncertainty ≤25 m, reported speed uncertainty ≤2 m/s, and a timestamp no older than three seconds. Invalid or lost readings show a dash.
- Acceleration timing requires stricter uncertainty (≤15 m and ≤1 m/s), two seconds at ≤0.5 m/s to arm, then ≥1.5 m/s to confirm launch. Start time is the **last observed stationary fix**. Target crossings use linear interpolation between raw speed samples. Slow launches taking over five seconds from the last stationary fix are discarded.
- A gap over 2.5 seconds, a rejected fix, or weak timing accuracy discards the current run and requires another stationary start. Out-of-order and duplicate fixes are ignored. Stop saves only achieved splits from a still-valid run. Reaching all targets, returning to rest, or the 120-second limit finalizes a run with achieved splits.
- Times display to tenths, but GPS sample interval and uncertainty can produce substantially larger errors, particularly at launch. This is an estimate, not a calibrated drag timer. No rollout correction, slope correction, external GNSS, or accelerometer launch detection is claimed.
- Distance uses trapezoidal integration of accepted GPS speeds, excluding gaps. Average = measured distance / measured time, including measured stationary periods. Session duration also includes time awaiting GPS. GPS drift can affect low-speed statistics.
- Coordinates/routes are not stored. Only summary statistics and completed runs are retained. Session checkpoints are saved on valid updates about every five seconds, when a run completes, and on backgrounding. Abrupt termination can lose recent unsaved data and any unfinished run.

## Build and verification

This delivery was authored on Windows. Project structure, property lists, shared source membership, resources, and source syntax were checked as described in `Docs/VALIDATION.md`. **Xcode compilation, Swift unit-test execution, signing, and physical-device behavior have not been verified here.**

On your Mac, run from this folder:

```sh
bash Scripts/verify.sh
```

This executes the Foundation-only calculation tests with `swift test`, then compiles the complete app and embedded widget for an iOS Simulator without signing. It does not assert that a simulator can validate real GPS or background behavior. Complete the physical-device checklist before relying on the app.

## Source map

| Location | Purpose |
| --- | --- |
| `ApexSpeed/TrackingStore.swift` | Permissions, GPS lifecycle, session model, persistence coordination |
| `Shared/SpeedCore.swift` | Units, quality gates, acceleration state machine, trip integration |
| `ApexSpeed/LiveActivityController.swift` | Activity start, ordered updates, stale dates, ending |
| `Shared/StopSessionIntent.swift` | Stop action executed in the app process |
| `ApexSpeedWidget/ApexSpeedWidget.swift` | All Live Activity presentations |
| `ApexSpeed/HistoryRepository.swift` | Atomic local JSON storage |
| `Tests/ApexCoreTests/SpeedCoreTests.swift` | Unit tests; synthetic inputs exist only here |
| `Config/Signing.xcconfig` | Your bundle identifier and optional team ID |

The project deliberately contains no AI service: all requested measurements are deterministic GPS calculations and require no API key or data upload.
