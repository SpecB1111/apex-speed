# Automatic GPS adjustment — version 1.1

Researched and implemented 8 October 2026.

The user identified [Speedo – Speedometer GPS by VIMI Studios](https://apps.apple.com/us/app/speedo-speedometer-gps/id946793911). Its version history documents a GPS signal strength view, but the public listing does not disclose its filtering algorithm. This implementation is independently designed; it does not claim to reproduce that app's internals.

Apple reports [horizontal accuracy](https://developer.apple.com/documentation/corelocation/cllocation/horizontalaccuracy) in metres and [speed accuracy](https://developer.apple.com/documentation/corelocation/cllocation/speedaccuracy) in metres per second. These are sensor estimates, not a setting that forces a particular physical accuracy. Apex already requests `kCLLocationAccuracyBestForNavigation` and disables the distance filter.

## Behaviour

| Quality | Reported position / speed accuracy | Display | Calculations |
| --- | --- | --- | --- |
| Strong | Up to 15 m and 1 m/s | Fast response | Raw GPS timing and trip statistics |
| Fair | Up to 25 m and 2 m/s | More smoothing, amber indicator | Raw trip statistics; acceleration run reset |
| Limited | Up to 65 m and 4 m/s | More smoothing, explicitly approximate; ~ in Island | Excluded from trip statistics and records; acceleration run reset |
| Unavailable | Invalid, outside limits, or older than 3 s | Dash, filter reset | No integration across missing data |

These cutoffs are application policy, not Apple guarantees. Quality always reflects the latest accepted measurement. Position and raw speed accuracy update on the dashboard; converting the speed unit also converts the displayed speed uncertainty.

The display uses a time-aware exponential low-pass filter with response constants 0.15 s / 0.5 s / 0.9 s. For elapsed sensor time dt, its weight is `1 - exp(-dt / responseTime)`. It only combines actual speed measurements; it does not predict between fixes. A gap over 2.5 s starts a fresh display estimate. A strong stationary fix immediately clears residual displayed motion. There is no intentional wait for extra samples, but smoothing adds some lag in weak reception. Gauge animation is a bounded 0.2-second ease-out, with Reduce Motion respected.

Timing never consumes smoothed values and still requires a new stationary arming period after degraded reception. Limited readings cannot update maximum speed or integrate distance; recovery does not fill the missing interval. The Dynamic Island uses the same filtered speed and marks limited readings approximate; iOS still controls visible refresh frequency.

## Verification

Nine new XCTest cases cover changing quality, unavailable accuracy, stronger weak-signal smoothing, fast recovery, stale fix clearing, gaps and out-of-order fixes, stationary recovery, rate-independent filtering, and protection of acceleration results. Existing tests cover timing, distance and history serialization. All fixtures remain in the test target only.

Physical-device checks still required: acquire GPS outdoors while stationary; observe the live quality/accuracy values; as a passenger check strong/weak reception transitions and restoration; confirm lost reception shows a dash; verify amber/~ Island presentation, Stop, and background updates. Do not handle the device while driving. No 0.5 m or instant-update accuracy claim is made.
