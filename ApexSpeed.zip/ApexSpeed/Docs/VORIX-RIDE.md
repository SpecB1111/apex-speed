# VØRIX Ride 1.2

VØRIX Ride updates the existing Apex Speed installation with a graphite/red identity, a new V app icon, automatic GPS quality adjustment, and a calibrated lean panel. Internal bundle identifiers, history location and project names are preserved to support updating the existing installation. Do not uninstall the old app before updating if you want to retain local history.

## Set lean zero

1. While parked on level ground, mount the phone securely in portrait. The phone's right edge should point toward the bike's right side. It can lie flat or slope toward you.
2. Hold the bike upright in its normal straight-ahead riding position, with both wheels level. Do not calibrate on the side stand.
3. Tap **Calibrate / Set zero** and remain steady for two seconds. Movement resets the countdown.
4. The display now shows signed lateral tilt relative to that zero, with left/right direction and peaks. Changing the mount requires recalibration. A cold app launch requires a new calibration.

Calibration uses the average direction of stable Core Motion gravity samples. The phone's right axis is projected perpendicular to calibrated gravity; subsequent gravity readings are projected into this lateral plane and measured with atan2. This supports a flat or sloped portrait mount and avoids counting pure forward pitch as lateral lean. A sideways portrait axis, near-singular projection, or angles beyond 90 degrees return unavailable rather than misleading values.

This is **estimated phone tilt**, not validated motorcycle lean telemetry. Core Motion fuses sensor data, but sustained acceleration, cornering forces, vibration and mounting errors can affect the result. The UI labels this feature beta. No certified precision or safe lean limit is implied.

Motion is sampled at a requested 30 Hz while the app is visible. Actual delivery is system-controlled. Readings clear after a sensor interruption; leaving the app stops motion sampling and returning resumes it. The GPS session and Dynamic Island speed continue separately. Lean is not shown in the Island and is not recorded in the background.

During an active GPS session, available estimated lean peaks are saved with history. Older records without lean fields still decode. Recalibration resets the panel's current peaks; the session keeps its largest observed estimates, even if the zero changed.

## Research

- [Apple: processed device motion](https://developer.apple.com/documentation/coremotion/getting-processed-device-motion-data): sensor fusion and reference frames.
- [Apple: gravity](https://developer.apple.com/documentation/coremotion/cmdevicemotion/gravity): gravity and user acceleration are separate processed outputs.
- [Apple: motion usage description](https://developer.apple.com/documentation/bundleresources/information-property-list/nsmotionusagedescription): a motion purpose string is included.
- See AUTO-GPS.md for the independently designed GPS adaptation and Speedo research.

## Device acceptance

Before a ride, check zero and left/right tilt while stationary with the phone fixed, including flat and sloped mounts. Check permission denial, movement during calibration, interruption, foreground/background return, and recalibration after a mount change. Confirm the older installation's history remains after updating with the same signing identity. Actual iPhone sensor and interface behaviour has not been physically validated by the build environment.
