# Verification on a Mac and physical iPhone

## Automated checks

Run `bash Scripts/verify.sh` in the project folder. The Swift package tests check unit conversions, an interpolated crossing, launch arming, no standing start, gap invalidation, weak accuracy, duplicate timestamps, multiple targets, rearming, partial splits, invalid readings, gap-aware trip integration, and model encoding. Synthetic measurements are confined to tests and never linked into the app.

The script then builds the app and embedded extension for an unsigned generic iOS Simulator destination. For signed validation, build and run the ApexSpeed scheme with your phone and team selected in Xcode. The app scheme does not contain an XCTest target: calculation tests are the adjacent Swift package and run through `swift test`.

## Physical-device checklist

Record phone model, iOS version, Xcode version, and whether the phone has Dynamic Island. Test initially stationary and on a safe low-speed walk; acceleration performance tests require a legal closed course and a mounted phone.

- Fresh install: both targets sign; app icon appears; permission request explains active background tracking.
- Deny permission: app remains idle with an actionable Settings message. Grant precise While Using permission and retry. Reduced accuracy should block start.
- No reception / indoors: no invented zero or default speed; speed remains a dash until a usable fix arrives.
- Good stationary fixes: shows measured speed; timing arms after the stationary dwell. Already moving at session start should not record a standing-start run.
- Switch to another app and lock/unlock the phone: verify GPS updates continue and the location indicator appears. Record actual Island cadence; do not require one-second visual refresh.
- Long-press Island: expanded layout, units, max and distance fit; Stop ends tracking and dismisses the activity. Repeat Stop from the Lock Screen while the app is backgrounded.
- Turn off Live Activities in system settings: tracking still works and history saves. Manually dismiss the card: GPS continues until explicitly stopped, as explained in Settings.
- Unit switch: compact, expanded and in-app units update; default timing targets remain 60 mph / 100 km/h / 160 km/h.
- Signal loss: app speed becomes a dash after the freshness limit; Island eventually marks stale and shows a dash. No crossing is interpolated across the outage. Regain signal and stop before rearming.
- Revoke location / disable Location Services mid-session: session stops and saves without a crash. Re-enable and start a fresh session.
- Stop in-app: updates stop, no orphan activity, history contains session statistics and achieved splits. Start again immediately: one new activity, new max/distance.
- Swipe-kill mid-session and reopen: checkpoint appears as interrupted, no tracking resumes automatically, orphan activity ends, incomplete run discarded. Do not expect immediate card removal while the process is dead.
- Relaunch after normal Stop: history and bests persist. Delete a history session: bests recompute. Add a custom target when stopped: it survives relaunch; target editing is blocked during tracking.
- Check maximum Dynamic Type, VoiceOver labels, Reduce Motion, and small-screen layouts. Verify the compact speed and units fit the actual Island with other activities present.
- Low Power Mode, a phone call, long locked-screen tracking, and power/thermal pressure: observe interruptions and stale behavior. GPS timing should never be treated as calibrated.
- Storage failure: surfaced save error; history read failure must preserve the unreadable file and prevent overwriting it with an empty history.

## Accuracy review

Compare against an independent calibrated instrument on a closed course before using estimates for decisions. Measure launch-detection error, sample gaps, speed uncertainty, target crossing error, and low-speed distance drift. The app’s 0.1-second formatting does not establish 0.1-second accuracy. Never test 0–160 km/h on public roads.
