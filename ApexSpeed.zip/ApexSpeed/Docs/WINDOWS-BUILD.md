# Build from Windows with GitHub Actions

The source stays editable on Windows. GitHub's hosted Mac compiles it. AltStore Classic on your own devices signs and installs the result. No Apple credentials belong in the repository or workflow.

1. Create a GitHub repository named `apex-speed`. Standard hosted runners in a public repository are free; public means anyone can read this app's source. A private repository instead uses your account's included Actions allowance and any configured billing limits.
2. Extract `ApexSpeed.zip`. Upload the **contents** of the extracted `ApexSpeed` folder into the repository root, not the ZIP and not an extra parent folder. Include the `.github` folder: it contains the build workflow. The root should contain `Package.swift`, `ApexSpeed.xcodeproj`, `Shared`, and `.github`.
3. Commit to `main`. Open the repository's **Actions** tab, then **Build Apex Speed for iPhone**. It starts on a main-branch push; you can also use **Run workflow**.
4. Wait for a successful run. If it fails, share the failed step's error text so the source or workflow can be repaired. This workflow has not yet been executed for this project.
5. In the successful run's **Artifacts**, download **ApexSpeed-unsigned**. Extract that download on Windows to obtain `ApexSpeed-unsigned.ipa`.
6. Transfer the IPA to Files on your iPhone. Keep AltServer running on Windows with the phone connected or reachable as required by AltStore. In AltStore Classic, go to **My Apps**, tap **+**, and select the IPA.
7. If asked whether to remove extensions, **keep the app extension**: the Dynamic Island UI needs it. The app and extension consume separate App IDs under free provisioning limits.
8. Finish signing inside AltStore using your own Apple Account. Enable Developer Mode if requested. Free signing expires after seven days; use AltStore to refresh before expiration.
9. Launch Apex Speed, grant precise location, and test a session while stationary before relying on it. Installation and the Live Activity extension must still be verified on your phone; a successful compilation alone does not prove device behavior.

The downloaded IPA is deliberately unsigned and cannot be installed directly by tapping it in Files. AltStore performs the personal signing. Do not remove the widget extension to work around signing errors; report the error instead.

References:
- [GitHub Actions billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions)
- [AltStore Classic for Windows](https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows)

The workflow executes only this project's Swift tests and Xcode build on a standard hosted Mac. It publishes a build artifact to the repository run for seven days, not to the App Store or a public release.
