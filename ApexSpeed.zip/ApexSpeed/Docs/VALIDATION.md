# Delivery validation

Version 1.0 was built successfully with Xcode 16.4 on a GitHub-hosted Mac; its 11 Swift tests passed. Build: https://github.com/SpecB1111/apex-speed/actions/runs/37627040060

Version 1.1 adds automatic GPS display filtering and live quality indicators. Windows static validation passed 139 checks, including syntax parsing of all 13 Swift files and Xcode project/plist/source membership validation. The Foundation package now contains 20 XCTest methods, including nine new adaptive GPS tests. The GitHub workflow runs these tests before producing the iPhone app and widget extension.

The source archive is submitted to GitHub Actions for the actual Swift tests and iOS build; check that version's successful workflow result before installing its artifact. Static syntax checks alone do not prove compilation or runtime behaviour.

Physical GPS accuracy, interface rendering, signing, background tracking, and Dynamic Island behaviour must still be checked on the intended iPhone. See AUTO-GPS.md and TESTING.md. No physical-device validation is claimed.
