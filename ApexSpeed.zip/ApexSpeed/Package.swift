// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "ApexCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "ApexCore", targets: ["ApexCore"])],
    targets: [
        .target(name: "ApexCore", path: "Shared", exclude: ["SpeedActivityAttributes.swift", "StopSessionIntent.swift"], sources: ["SpeedCore.swift"]),
        .testTarget(name: "ApexCoreTests", dependencies: ["ApexCore"], path: "Tests/ApexCoreTests")
    ]
)
