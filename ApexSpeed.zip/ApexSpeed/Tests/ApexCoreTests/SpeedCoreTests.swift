import XCTest
@testable import ApexCore

final class SpeedCoreTests: XCTestCase {
    let origin = Date(timeIntervalSince1970: 1_000)
    func sample(_ seconds: Double, _ speed: Double, accuracy: Double = 0.2) -> SpeedSample {
        SpeedSample(time: origin.addingTimeInterval(seconds), speed: speed,
                    horizontalAccuracy: 5, speedAccuracy: accuracy)
    }
    func armed(_ targets: [SpeedTarget]) -> AccelerationEngine {
        var engine = AccelerationEngine(targets: targets)
        for second in 0...2 { _ = engine.consume(sample(Double(second), 0)) }
        return engine
    }

    func testConversionsAndDefaultTargets() {
        XCTAssertEqual(SpeedUnit.kmh.display(10), 36, accuracy: 1e-9)
        XCTAssertEqual(SpeedTarget(value: 60, unit: .mph).speed, 26.8224, accuracy: 1e-6)
        XCTAssertEqual(SpeedTarget.defaults.count, 3)
    }
    func testStandingStartAndInterpolatedCrossing() throws {
        var engine = armed([SpeedTarget(value: 36, unit: .kmh)])
        XCTAssertNil(engine.consume(sample(3, 6)))
        let run = try XCTUnwrap(engine.consume(sample(4, 12)))
        XCTAssertEqual(run.started, origin.addingTimeInterval(2))
        // Date stores absolute seconds; allow its sub-microsecond rounding.
        XCTAssertEqual(run.splits[0].seconds, 1 + 4.0 / 6, accuracy: 1e-6)
    }
    func testAlreadyMovingNeverStarts() {
        var engine = AccelerationEngine(targets: [SpeedTarget(value: 36, unit: .kmh)])
        for second in 0...8 { XCTAssertNil(engine.consume(sample(Double(second), Double(second) * 5))) }
        XCTAssertNil(engine.finish())
    }
    func testGapDiscardsInProgressRun() {
        var engine = armed(SpeedTarget.defaults)
        _ = engine.consume(sample(3, 10))
        _ = engine.consume(sample(7, 40))
        XCTAssertNil(engine.finish())
    }
    func testWeakAccuracyDiscardsPartialSplits() {
        var engine = armed(SpeedTarget.defaults)
        _ = engine.consume(sample(3, 30))
        XCTAssertEqual(engine.splits.count, 2)
        _ = engine.consume(sample(4, 40, accuracy: 1.5))
        XCTAssertNil(engine.finish())
    }
    func testDuplicateTimestampDoesNotCreateCrossing() {
        var engine = armed([SpeedTarget(value: 36, unit: .kmh)])
        _ = engine.consume(sample(3, 5))
        XCTAssertNil(engine.consume(sample(3, 20)))
        XCTAssertTrue(engine.splits.isEmpty)
    }
    func testMultipleTargetsInOneFixAndRearming() throws {
        var engine = armed([SpeedTarget(value: 18, unit: .kmh), SpeedTarget(value: 36, unit: .kmh)])
        let first = try XCTUnwrap(engine.consume(sample(3, 15)))
        XCTAssertEqual(first.splits.count, 2)
        XCTAssertEqual(first.splits[0].seconds, 1.0 / 3, accuracy: 1e-6)
        XCTAssertNil(engine.consume(sample(4, 20)))
        for second in 5...7 { _ = engine.consume(sample(Double(second), 0)) }
        XCTAssertNotNil(engine.consume(sample(8, 15)))
    }
    func testStopSavesOnlyReachedTargets() throws {
        var engine = armed(SpeedTarget.defaults)
        _ = engine.consume(sample(3, 30))
        let run = try XCTUnwrap(engine.finish())
        XCTAssertEqual(run.splits.count, 2)
        XCTAssertFalse(run.splits.contains { $0.target.value == 160 })
    }
    func testInvalidSpeedTimestampAndAccuracyAreRejected() {
        XCTAssertFalse(sample(0, -1).usable(at: origin))
        XCTAssertFalse(sample(0, .nan).usable(at: origin))
        XCTAssertFalse(sample(0, 20, accuracy: -1).usable(at: origin))
        XCTAssertFalse(sample(0, 20).usable(at: origin.addingTimeInterval(4)))
        XCTAssertFalse(sample(2, 20).usable(at: origin))
        XCTAssertTrue(sample(0, 20).usable(at: origin))
    }
    func testDistanceExcludesGapsAndDuplicateFixes() {
        var trip = TripAccumulator()
        var record = SessionRecord(started: origin, updated: origin)
        trip.consume(sample(0, 10), record: &record)
        trip.consume(sample(1, 20), record: &record)
        trip.consume(sample(1, 50), record: &record)
        trip.consume(sample(5, 30), record: &record)
        XCTAssertEqual(record.distance, 15, accuracy: 1e-9)
        XCTAssertEqual(record.measuredSeconds, 1)
        XCTAssertEqual(record.maxSpeed, 30)
        XCTAssertEqual(record.averageSpeed, 15)
    }
    func testArchiveRoundTrip() throws {
        var record = SessionRecord(started: origin, updated: origin)
        var engine = armed([SpeedTarget(value: 36, unit: .kmh)])
        record.runs = [try XCTUnwrap(engine.consume(sample(3, 15)))]
        let restored = try JSONDecoder().decode(SessionRecord.self, from: JSONEncoder().encode(record))
        XCTAssertEqual(restored.id, record.id)
        XCTAssertEqual(restored.runs[0].splits[0].target.id, "36-kmh")
    }

    func testDisplayQualityAdaptsWithoutRelaxingTiming() {
        var fix = sample(0, 20)
        XCTAssertEqual(fix.displayQuality(at: origin), .strong)
        fix.horizontalAccuracy = 20
        XCTAssertEqual(fix.displayQuality(at: origin), .fair)
        XCTAssertFalse(fix.suitableForTiming)
        fix.horizontalAccuracy = 50; fix.speedAccuracy = 3
        XCTAssertEqual(fix.displayQuality(at: origin), .limited)
        XCTAssertFalse(fix.usable(at: origin))
        XCTAssertFalse(fix.suitableForTiming)
        fix.horizontalAccuracy = 66
        XCTAssertEqual(fix.displayQuality(at: origin), .unavailable)
    }

    func testUnknownOrInvalidAccuracyNeverBecomesStrong() {
        for invalid in [-1.0, Double.nan, Double.infinity] {
            var fix = sample(0, 20, accuracy: invalid)
            XCTAssertEqual(fix.displayQuality(at: origin), .unavailable)
            XCTAssertFalse(fix.suitableForTiming)
            fix = sample(0, 20); fix.horizontalAccuracy = invalid
            XCTAssertEqual(fix.displayQuality(at: origin), .unavailable)
            XCTAssertFalse(fix.suitableForTiming)
        }
    }

    func testWeakReadingsAreSmoothedMoreThanStrongReadings() throws {
        var strong = AdaptiveSpeedDisplay()
        var weak = AdaptiveSpeedDisplay()
        _ = strong.consume(sample(0, 10), at: origin)
        _ = weak.consume(sample(0, 10), at: origin)
        let fast = try XCTUnwrap(strong.consume(sample(1, 20), at: origin.addingTimeInterval(1)))
        let smooth = try XCTUnwrap(weak.consume(sample(1, 20, accuracy: 3), at: origin.addingTimeInterval(1)))
        XCTAssertGreaterThan(fast, 19.9)
        XCTAssertGreaterThan(smooth, 10)
        XCTAssertLessThan(smooth, fast)
        XCTAssertLessThanOrEqual(fast, 20) // no predicted overshoot
    }

    func testRecoveryFromWeakSignalRespondsQuickly() throws {
        var display = AdaptiveSpeedDisplay()
        _ = display.consume(sample(0, 10, accuracy: 3), at: origin)
        _ = display.consume(sample(1, 30, accuracy: 3), at: origin.addingTimeInterval(1))
        let recovered = try XCTUnwrap(display.consume(sample(2, 35), at: origin.addingTimeInterval(2)))
        XCTAssertEqual(recovered, 35, accuracy: 0.1)
    }

    func testDisplayClearsStaleFixAndRestartsWithoutOldSpeed() throws {
        var display = AdaptiveSpeedDisplay()
        _ = display.consume(sample(0, 30), at: origin)
        XCTAssertNil(display.consume(sample(1, 25), at: origin.addingTimeInterval(5)))
        XCTAssertNil(display.speed)
        XCTAssertEqual(try XCTUnwrap(display.consume(sample(6, 5), at: origin.addingTimeInterval(6))), 5)
    }

    func testDisplayDoesNotBridgeSignalGapsOrRegressToOlderFixes() throws {
        var display = AdaptiveSpeedDisplay()
        _ = display.consume(sample(0, 30), at: origin)
        XCTAssertEqual(try XCTUnwrap(display.consume(sample(4, 10), at: origin.addingTimeInterval(4))), 10)
        XCTAssertEqual(try XCTUnwrap(display.consume(sample(3, 50), at: origin.addingTimeInterval(4))), 10)
        XCTAssertEqual(try XCTUnwrap(display.consume(sample(4, 80), at: origin.addingTimeInterval(4))), 10)
    }

    func testStrongStopDoesNotLeaveGhostSpeed() throws {
        var display = AdaptiveSpeedDisplay()
        _ = display.consume(sample(0, 10), at: origin)
        XCTAssertEqual(try XCTUnwrap(display.consume(sample(1, 0), at: origin.addingTimeInterval(1))), 0)
    }

    func testFilteringIsConsistentAcrossSampleRates() throws {
        var slow = AdaptiveSpeedDisplay()
        var fast = AdaptiveSpeedDisplay()
        _ = slow.consume(sample(0, 10, accuracy: 3), at: origin)
        _ = fast.consume(sample(0, 10, accuracy: 3), at: origin)
        let once = try XCTUnwrap(slow.consume(sample(1, 20, accuracy: 3), at: origin.addingTimeInterval(1)))
        for step in 1...4 {
            let seconds = Double(step) / 4
            _ = fast.consume(sample(seconds, 20, accuracy: 3), at: origin.addingTimeInterval(seconds))
        }
        XCTAssertEqual(try XCTUnwrap(fast.speed), once, accuracy: 1e-6)
    }

    func testApproximateDisplayCannotFinishOrResumeAnAccelerationRun() {
        var engine = armed(SpeedTarget.defaults)
        _ = engine.consume(sample(3, 30))
        XCTAssertEqual(engine.splits.count, 2)
        XCTAssertNil(engine.consume(sample(4, 50, accuracy: 3)))
        XCTAssertTrue(engine.splits.isEmpty)
        XCTAssertNil(engine.consume(sample(5, 55)))
        XCTAssertNil(engine.finish())
    }

    func testFlatMountCalibratesAndMeasuresBothLeanDirections() throws {
        let zero = try XCTUnwrap(LeanCalibration(gravity: .init(x: 0, y: 0, z: -1)))
        XCTAssertEqual(try XCTUnwrap(zero.degrees(gravity: .init(x: 0, y: 0, z: -1))), 0, accuracy: 1e-9)
        XCTAssertEqual(try XCTUnwrap(zero.degrees(gravity: .init(x: 0.5, y: 0, z: -sqrt(0.75)))), 30, accuracy: 1e-9)
        XCTAssertEqual(try XCTUnwrap(zero.degrees(gravity: .init(x: -0.5, y: 0, z: -sqrt(0.75)))), -30, accuracy: 1e-9)
    }

    func testUprightAndSlopedMountsUseTheirOwnZero() throws {
        let upright = try XCTUnwrap(LeanCalibration(gravity: .init(x: 0, y: -1, z: 0)))
        XCTAssertEqual(try XCTUnwrap(upright.degrees(gravity: .init(x: 0.5, y: -sqrt(0.75), z: 0))), 30, accuracy: 1e-9)
        let base = MotionVector(x: 0, y: -sqrt(0.5), z: -sqrt(0.5))
        let sloped = try XCTUnwrap(LeanCalibration(gravity: base))
        XCTAssertEqual(try XCTUnwrap(sloped.degrees(gravity: base)), 0, accuracy: 1e-9)
        let rolled = MotionVector(x: 0.5, y: base.y * sqrt(0.75), z: base.z * sqrt(0.75))
        XCTAssertEqual(try XCTUnwrap(sloped.degrees(gravity: rolled)), 30, accuracy: 1e-9)
    }

    func testForwardPitchDoesNotBecomeLateralLean() throws {
        let zero = try XCTUnwrap(LeanCalibration(gravity: .init(x: 0, y: 0, z: -1)))
        XCTAssertEqual(try XCTUnwrap(zero.degrees(gravity: .init(x: 0, y: 0.5, z: -sqrt(0.75)))), 0, accuracy: 1e-9)
    }

    func testInvalidAndAmbiguousMotionReturnsNoAngle() throws {
        XCTAssertNil(LeanCalibration(gravity: .init(x: 0, y: 0, z: 0)))
        XCTAssertNil(LeanCalibration(gravity: .init(x: .nan, y: 0, z: -1)))
        XCTAssertNil(LeanCalibration(gravity: .init(x: 1, y: 0, z: 0)))
        let zero = try XCTUnwrap(LeanCalibration(gravity: .init(x: 0, y: 0, z: -1)))
        XCTAssertNil(zero.degrees(gravity: .init(x: 0, y: 1, z: 0)))
        XCTAssertNil(zero.degrees(gravity: .init(x: 0, y: 0, z: 1)))
    }

    func testCalibrationRequiresTwoSecondsOfSteadyMotion() throws {
        var capture = LeanZeroCapture()
        let down = MotionVector(x: 0, y: 0, z: -1)
        for step in 0..<60 {
            XCTAssertNil(capture.consume(time: Double(step) / 30, gravity: down, rotation: 0, acceleration: 0))
        }
        let zero = try XCTUnwrap(capture.consume(time: 2, gravity: down, rotation: 0, acceleration: 0))
        XCTAssertEqual(try XCTUnwrap(zero.degrees(gravity: down)), 0, accuracy: 1e-9)
    }

    func testMovementAndGapsRestartCalibration() {
        var capture = LeanZeroCapture()
        let down = MotionVector(x: 0, y: 0, z: -1)
        for step in 0...30 { _ = capture.consume(time: Double(step) / 30, gravity: down, rotation: 0, acceleration: 0) }
        XCTAssertGreaterThan(capture.progress, 0.4)
        XCTAssertNil(capture.consume(time: 1.1, gravity: down, rotation: 0.2, acceleration: 0))
        XCTAssertEqual(capture.progress, 0)
        _ = capture.consume(time: 1.2, gravity: down, rotation: 0, acceleration: 0)
        XCTAssertNil(capture.consume(time: 4, gravity: down, rotation: 0, acceleration: 0))
        XCTAssertEqual(capture.progress, 0)
        _ = capture.consume(time: 4.03, gravity: down, rotation: 0, acceleration: 0.2)
        XCTAssertEqual(capture.progress, 0)
    }

    func testMountDriftRestartsZeroCapture() {
        var capture = LeanZeroCapture()
        for step in 0...30 { _ = capture.consume(time: Double(step) / 30, gravity: .init(x: 0, y: 0, z: -1), rotation: 0, acceleration: 0) }
        XCTAssertNil(capture.consume(time: 1.03, gravity: .init(x: 0.2, y: 0, z: -sqrt(0.96)), rotation: 0, acceleration: 0))
        XCTAssertEqual(capture.progress, 0)
    }

    func testOldHistoryLoadsWithoutLeanAndNewPeaksRoundTrip() throws {
        var record = SessionRecord(started: origin, updated: origin)
        let oldData = try JSONEncoder().encode(record)
        let restored = try JSONDecoder().decode(SessionRecord.self, from: oldData)
        XCTAssertNil(restored.maxLeanLeft)
        record.maxLeanLeft = 25; record.maxLeanRight = 32
        let updated = try JSONDecoder().decode(SessionRecord.self, from: JSONEncoder().encode(record))
        XCTAssertEqual(updated.maxLeanLeft, 25)
        XCTAssertEqual(updated.maxLeanRight, 32)
    }
}
