import XCTest
@testable import ApexCore

final class SpeedCoreTests: XCTestCase {
    let origin = Date(timeIntervalSince1970: 1_000)
    func sample(_ seconds: Double, _ speed: Double, accuracy: Double = 0.2) -> SpeedSample {
        SpeedSample(time: origin.addingTimeInterval(seconds), speed: speed,
                    horizontalAccuracy: 5, speedAccuracy: accuracy)
    }
    func armed(_ targets: [SpeedTarget]) -> AccelerationEngine {
        var engine = AccelerationEngine(targets: targets)
        for second in 0...2 { _ = engine.consume(sample(Double(second), 0)) }
        return engine
    }

    func testConversionsAndDefaultTargets() {
        XCTAssertEqual(SpeedUnit.kmh.display(10), 36, accuracy: 1e-9)
        XCTAssertEqual(SpeedTarget(value: 60, unit: .mph).speed, 26.8224, accuracy: 1e-6)
        XCTAssertEqual(SpeedTarget.defaults.count, 3)
    }
    func testStandingStartAndInterpolatedCrossing() throws {
        var engine = armed([SpeedTarget(value: 36, unit: .kmh)])
        XCTAssertNil(engine.consume(sample(3, 6)))
        let run = try XCTUnwrap(engine.consume(sample(4, 12)))
        XCTAssertEqual(run.started, origin.addingTimeInterval(2))
        // Date stores absolute seconds; allow its sub-microsecond rounding.
        XCTAssertEqual(run.splits[0].seconds, 1 + 4.0 / 6, accuracy: 1e-6)
    }
    func testAlreadyMovingNeverStarts() {
        var engine = AccelerationEngine(targets: [SpeedTarget(value: 36, unit: .kmh)])
        for second in 0...8 { XCTAssertNil(engine.consume(sample(Double(second), Double(second) * 5))) }
        XCTAssertNil(engine.finish())
    }
    func testGapDiscardsInProgressRun() {
        var engine = armed(SpeedTarget.defaults)
        _ = engine.consume(sample(3, 10))
        _ = engine.consume(sample(7, 40))
        XCTAssertNil(engine.finish())
    }
    func testWeakAccuracyDiscardsPartialSplits() {
        var engine = armed(SpeedTarget.defaults)
        _ = engine.consume(sample(3, 30))
        XCTAssertEqual(engine.splits.count, 2)
        _ = engine.consume(sample(4, 40, accuracy: 1.5))
        XCTAssertNil(engine.finish())
    }
    func testDuplicateTimestampDoesNotCreateCrossing() {
        var engine = armed([SpeedTarget(value: 36, unit: .kmh)])
        _ = engine.consume(sample(3, 5))
        XCTAssertNil(engine.consume(sample(3, 20)))
        XCTAssertTrue(engine.splits.isEmpty)
    }
    func testMultipleTargetsInOneFixAndRearming() throws {
        var engine = armed([SpeedTarget(value: 18, unit: .kmh), SpeedTarget(value: 36, unit: .kmh)])
        let first = try XCTUnwrap(engine.consume(sample(3, 15)))
        XCTAssertEqual(first.splits.count, 2)
        XCTAssertEqual(first.splits[0].seconds, 1.0 / 3, accuracy: 1e-6)
        XCTAssertNil(engine.consume(sample(4, 20)))
        for second in 5...7 { _ = engine.consume(sample(Double(second), 0)) }
        XCTAssertNotNil(engine.consume(sample(8, 15)))
    }
    func testStopSavesOnlyReachedTargets() throws {
        var engine = armed(SpeedTarget.defaults)
        _ = engine.consume(sample(3, 30))
        let run = try XCTUnwrap(engine.finish())
        XCTAssertEqual(run.splits.count, 2)
        XCTAssertFalse(run.splits.contains { $0.target.value == 160 })
    }
    func testInvalidSpeedTimestampAndAccuracyAreRejected() {
        XCTAssertFalse(sample(0, -1).usable(at: origin))
        XCTAssertFalse(sample(0, .nan).usable(at: origin))
        XCTAssertFalse(sample(0, 20, accuracy: -1).usable(at: origin))
        XCTAssertFalse(sample(0, 20).usable(at: origin.addingTimeInterval(4)))
        XCTAssertFalse(sample(2, 20).usable(at: origin))
        XCTAssertTrue(sample(0, 20).usable(at: origin))
    }
    func testDistanceExcludesGapsAndDuplicateFixes() {
        var trip = TripAccumulator()
        var record = SessionRecord(started: origin, updated: origin)
        trip.consume(sample(0, 10), record: &record)
        trip.consume(sample(1, 20), record: &record)
        trip.consume(sample(1, 50), record: &record)
        trip.consume(sample(5, 30), record: &record)
        XCTAssertEqual(record.distance, 15, accuracy: 1e-9)
        XCTAssertEqual(record.measuredSeconds, 1)
        XCTAssertEqual(record.maxSpeed, 30)
        XCTAssertEqual(record.averageSpeed, 15)
    }
    func testArchiveRoundTrip() throws {
        var record = SessionRecord(started: origin, updated: origin)
        var engine = armed([SpeedTarget(value: 36, unit: .kmh)])
        record.runs = [try XCTUnwrap(engine.consume(sample(3, 15)))]
        let restored = try JSONDecoder().decode(SessionRecord.self, from: JSONEncoder().encode(record))
        XCTAssertEqual(restored.id, record.id)
        XCTAssertEqual(restored.runs[0].splits[0].target.id, "36-kmh")
    }
}
