import ActivityKit
import SwiftUI
import WidgetKit

@main
struct ApexSpeedWidgetBundle: WidgetBundle {
    var body: some Widget { ApexSpeedLiveActivity() }
}

struct ApexSpeedLiveActivity: Widget {
    private let accent = Color(red: 1, green: 0.24, blue: 0.3)
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: SpeedActivityAttributes.self) { context in
            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("VØRIX RIDE").font(.caption2.weight(.heavy)).tracking(2).foregroundStyle(accent)
                    HStack(alignment: .firstTextBaseline, spacing: 5) {
                        speed(context).font(.system(size: 40, weight: .semibold, design: .rounded))
                        Text(context.state.unit).font(.caption).foregroundStyle(.secondary)
                    }
                    Text(context.isStale ? "GPS stale · reopen app" : context.state.status)
                        .font(.caption2).lineLimit(1)
                }
                Spacer(minLength: 0)
                VStack(alignment: .trailing, spacing: 9) {
                    Text("MAX \(context.state.maxSpeed) \(context.state.unit)").font(.caption2.monospacedDigit())
                    Text(context.state.distance).font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                    Button(intent: StopSessionIntent()) { Label("Stop", systemImage: "stop.fill") }
                        .tint(.red).buttonStyle(.bordered)
                }
            }.padding(16)
                .activityBackgroundTint(Color(red: 0.04, green: 0.05, blue: 0.07))
                .activitySystemActionForegroundColor(.white)
                .widgetURL(URL(string: "apexspeed://session"))
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("VØRIX").font(.caption2.weight(.black)).foregroundStyle(accent)
                        speed(context).font(.system(size: 34, weight: .medium, design: .rounded))
                    }
                }
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 6) {
                        Text(context.state.unit).foregroundStyle(accent)
                        Text("MAX \(context.state.maxSpeed)").font(.caption2)
                        Text(context.state.distance).font(.caption2).foregroundStyle(.secondary)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    HStack {
                        Text(context.isStale ? "GPS stale · reopen app" : context.state.status)
                            .font(.caption2).lineLimit(2)
                        Spacer()
                        Button(intent: StopSessionIntent()) { Label("Stop", systemImage: "stop.fill") }
                            .tint(.red).buttonStyle(.bordered)
                    }
                }
            } compactLeading: {
                Image(systemName: context.isStale ? "location.slash" : "speedometer")
                    .foregroundStyle(context.state.approximate == true ? Color.orange : accent)
            } compactTrailing: {
                HStack(spacing: 2) {
                    speed(context).font(.system(size: 15, weight: .semibold, design: .rounded))
                    Text(context.state.unit == "mph" ? "mph" : "km/h").font(.system(size: 8))
                }
            } minimal: {
                speed(context).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(accent)
            }
            .keylineTint(accent)
            .widgetURL(URL(string: "apexspeed://session"))
        }
    }

    private func speed(_ context: ActivityViewContext<SpeedActivityAttributes>) -> some View {
        Text(context.isStale ? "—" : context.state.speed.map { (context.state.approximate == true ? "~" : "") + String($0) } ?? "—")
            .monospacedDigit().contentTransition(.numericText()).lineLimit(1).minimumScaleFactor(0.6)
            .accessibilityLabel(context.isStale || context.state.speed == nil ? "Speed unavailable" : "\(context.state.speed ?? 0) \(context.state.unit)")
    }
}
