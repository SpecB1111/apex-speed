#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v xcodebuild >/dev/null; then
  echo "Run this script on a Mac with Xcode selected as the developer tools."
  exit 1
fi
swift test
xcodebuild -project ApexSpeed.xcodeproj -scheme ApexSpeed \
  -configuration Debug -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO build
