#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."

# No Apple password or certificate is needed for this unsigned build.
# AltStore on the user's devices supplies the final personal signing.
xcodebuild -project ApexSpeed.xcodeproj -scheme ApexSpeed \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath build/DeviceDerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= build

app="build/DeviceDerivedData/Build/Products/Release-iphoneos/ApexSpeed.app"
test -f "$app/ApexSpeed"
test -f "$app/PlugIns/ApexSpeedWidget.appex/ApexSpeedWidget"
staging="$(mktemp -d "${TMPDIR:-/tmp}/apex-package.XXXXXX")"
mkdir -p "$staging/Payload"
ditto "$app" "$staging/Payload/ApexSpeed.app"
output="$PWD/build/ApexSpeed-unsigned.ipa"
ditto -c -k --keepParent "$staging/Payload" "$output"
unzip -t "$output"
echo "Packaged unsigned IPA: $output"
