import SwiftUI
import CoreMotion
import UIKit

@MainActor
final class LeanMotion: ObservableObject {
    @Published private(set) var degrees: Double?
    @Published private(set) var peakLeft = 0.0
    @Published private(set) var peakRight = 0.0
    @Published private(set) var progress = 0.0
    @Published private(set) var calibrating = false
    @Published private(set) var enabled = false
    @Published private(set) var status = "Mount your phone, then set zero"
    private let motion = CMMotionManager()
    private var zero: LeanCalibration?
    private var capture = LeanZeroCapture()
    private var lastTimestamp: Double?
    private var lastReceipt: Date?
    private var watchdog: Timer?
    private var generation = 0

    func setZero() {
        guard motion.isDeviceMotionAvailable else { status = "Motion sensor unavailable on this device"; return }
        zero = nil; degrees = nil; peakLeft = 0; peakRight = 0
        capture.reset(); progress = 0; calibrating = true; enabled = true
        status = "Hold the bike upright and still for 2 seconds"
        start()
    }

    func start() {
        guard enabled, !motion.isDeviceMotionActive else { return }
        guard motion.isDeviceMotionAvailable else { status = "Motion sensor unavailable"; return }
        generation += 1
        let token = generation
        lastTimestamp = nil; lastReceipt = nil
        motion.deviceMotionUpdateInterval = 1.0 / 30.0
        motion.startDeviceMotionUpdates(using: .xArbitraryZVertical, to: .main) { [weak self] data, error in
            Task { @MainActor in
                guard let self, token == self.generation else { return }
                guard let data, error == nil else {
                    self.degrees = nil; self.status = "Motion unavailable · check permissions"; return
                }
                self.consume(data)
            }
        }
        watchdog?.invalidate()
        watchdog = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                if self.lastReceipt == nil || Date().timeIntervalSince(self.lastReceipt!) > 0.5 {
                    self.degrees = nil
                    self.capture.reset(); self.progress = 0
                    self.status = "Waiting for motion sensor"
                }
            }
        }
    }

    func suspend() {
        generation += 1
        motion.stopDeviceMotionUpdates(); watchdog?.invalidate(); watchdog = nil
        degrees = nil; lastReceipt = nil; capture.reset(); progress = 0
        if enabled { status = "Lean paused · open the app to resume" }
    }

    private func consume(_ data: CMDeviceMotion) {
        if let lastTimestamp, data.timestamp <= lastTimestamp { return }
        let gap = lastTimestamp.map { data.timestamp - $0 } ?? 0
        lastTimestamp = data.timestamp; lastReceipt = Date()
        let gravity = MotionVector(x: data.gravity.x, y: data.gravity.y, z: data.gravity.z)
        let rotation = MotionVector(x: data.rotationRate.x, y: data.rotationRate.y, z: data.rotationRate.z).length
        let acceleration = MotionVector(x: data.userAcceleration.x, y: data.userAcceleration.y, z: data.userAcceleration.z).length
        if calibrating {
            let result = capture.consume(time: data.timestamp, gravity: gravity, rotation: rotation, acceleration: acceleration)
            progress = capture.progress
            if let result {
                zero = result; calibrating = false; degrees = 0
                status = "Zero set · estimated phone lean"
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            } else {
                status = progress > 0 ? "Hold steady · setting zero" : "Keep upright and still · portrait mount"
            }
            return
        }
        guard let zero, let raw = zero.degrees(gravity: gravity), rotation.isFinite, acceleration.isFinite else {
            degrees = nil; status = "Outside tilt range · check phone mount"; return
        }
        // Smooth only the visual value; reset after interruptions rather than bridging a gap.
        let weight = gap > 0 && gap <= 0.5 ? 1 - exp(-gap / 0.08) : 1
        degrees = (degrees ?? raw) + weight * (raw - (degrees ?? raw))
        if let degrees {
            peakLeft = max(peakLeft, max(0, -degrees))
            peakRight = max(peakRight, max(0, degrees))
        }
        status = acceleration > 0.3 ? "Dynamic forces · estimate may drift" : "Calibrated · estimated phone lean"
    }
}

struct LeanPanel: View {
    @StateObject private var lean = LeanMotion()
    @EnvironmentObject private var tracker: TrackingStore
    @Environment(\.scenePhase) private var scene
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        VStack(spacing: 18) {
            HStack {
                Label("LEAN ANGLE", systemImage: "gyroscope").font(.caption.weight(.bold)).tracking(2)
                Spacer()
                Text("BETA").font(.system(size: 9, weight: .bold)).padding(.horizontal, 8).padding(.vertical, 4)
                    .background(Color.white.opacity(0.08), in: Capsule())
            }
            ZStack {
                RoundedRectangle(cornerRadius: 2).fill(Color.white.opacity(0.12)).frame(height: 1)
                ForEach([-60, -30, 0, 30, 60], id: \.self) { angle in
                    Capsule().fill(Color.white.opacity(angle == 0 ? 0.5 : 0.15)).frame(width: 2, height: 8)
                        .offset(y: -65).rotationEffect(.degrees(Double(angle)))
                }
                Image(systemName: "motorcycle.fill").font(.system(size: 39)).foregroundStyle(ApexTheme.accent)
                    .rotationEffect(.degrees(lean.degrees ?? 0))
                    .opacity(lean.degrees == nil ? 0.3 : 1)
                HStack {
                    Text("L"); Spacer(); Text("R")
                }.font(.caption2.weight(.bold)).foregroundStyle(.secondary)
            }.frame(height: 110).padding(.horizontal, 12)
                .animation(reduceMotion ? nil : .linear(duration: 0.06), value: lean.degrees)
                .accessibilityHidden(true)
            Text(lean.degrees.map { String(format: "%.0f°", abs($0)) } ?? "—°")
                .font(.system(size: 56, weight: .light, design: .rounded)).monospacedDigit()
                .accessibilityLabel(lean.degrees.map { String(format: "Estimated tilt %.0f degrees %@", abs($0), $0 < -0.5 ? "left" : $0 > 0.5 ? "right" : "upright") } ?? "Lean not calibrated or unavailable")
            Text(lean.degrees.map { $0 < -0.5 ? "LEFT" : $0 > 0.5 ? "RIGHT" : "UPRIGHT" } ?? "SET YOUR ZERO")
                .font(.caption2.weight(.semibold)).tracking(3).foregroundStyle(ApexTheme.accent)
            HStack {
                Text(String(format: "LEFT PEAK %.0f°", lean.peakLeft))
                Spacer()
                Text(String(format: "RIGHT PEAK %.0f°", lean.peakRight))
            }.font(.caption2.monospacedDigit()).foregroundStyle(.secondary)
            if lean.calibrating { ProgressView(value: lean.progress).tint(ApexTheme.accent) }
            Text(lean.status).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button { lean.setZero() } label: {
                Label(lean.calibrating ? "Restart calibration" : "Calibrate / Set zero", systemImage: "scope")
                    .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity).padding(14)
                    .background(ApexTheme.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
            }.disabled((tracker.speed ?? 0) > 0.5)
            Text("While parked, hold the bike upright with both wheels level—not on its side stand. Mount the phone in portrait with its right edge toward the bike’s right; it can lie flat or face you. Tap Set zero and hold still. Recalibrate if the mount moves.")
                .font(.caption2).foregroundStyle(.secondary)
            Text("Phone tilt estimate, not a certified bike lean angle. Cornering forces and vibration can affect it. Lean readings pause when you leave the app.")
                .font(.caption2).foregroundStyle(.secondary)
        }.padding(20).background(ApexTheme.panel, in: RoundedRectangle(cornerRadius: 24))
            .onAppear { lean.start() }
            .onDisappear { lean.suspend() }
            .onChange(of: scene) { _, phase in
                if phase == .active { lean.start() } else { lean.suspend() }
            }
            .onChange(of: lean.degrees) { _, degrees in
                if let degrees, !lean.calibrating { tracker.recordLean(degrees) }
            }
    }
}
