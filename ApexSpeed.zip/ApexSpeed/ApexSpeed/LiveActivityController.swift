import ActivityKit
import Foundation

@MainActor
final class LiveActivityController {
    private var activity: Activity<SpeedActivityAttributes>?
    private var pending: Task<Void, Never>?
    private var lastSent = Date.distantPast

    func clearOrphans() async {
        for existing in Activity<SpeedActivityAttributes>.activities {
            await existing.end(nil, dismissalPolicy: .immediate)
        }
    }

    func start(record: SessionRecord, state: SpeedActivityAttributes.ContentState) -> String? {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            return "Live Activities are disabled. Enable them in Settings for VØRIX Ride. GPS tracking still works."
        }
        do {
            activity = try Activity.request(
                attributes: SpeedActivityAttributes(sessionID: record.id, started: record.started),
                content: ActivityContent(state: state, staleDate: Date().addingTimeInterval(5)), pushType: nil)
            lastSent = .distantPast
            return nil
        } catch { return "Could not show the Live Activity: \(error.localizedDescription)" }
    }

    func update(_ state: SpeedActivityAttributes.ContentState, force: Bool = false) {
        guard let activity, force || Date().timeIntervalSince(lastSent) >= 1 else { return }
        guard activity.activityState == .active || activity.activityState == .stale else { return }
        lastSent = Date()
        let previous = pending
        pending = Task {
            await previous?.value
            await activity.update(ActivityContent(state: state, staleDate: state.updated.addingTimeInterval(5)))
        }
    }

    func end() async {
        let ending = activity
        activity = nil
        await pending?.value
        pending = nil
        if let ending { await ending.end(nil, dismissalPolicy: .immediate) }
        // Also covers an intent waking a previously terminated app.
        await clearOrphans()
    }
}
