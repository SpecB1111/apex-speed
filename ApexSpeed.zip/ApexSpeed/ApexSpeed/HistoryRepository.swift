import Foundation

struct HistoryArchive: Codable {
    var version = 1
    var sessions: [SessionRecord] = []
    var active: SessionRecord?
}

struct HistoryRepository {
    let url: URL
    init() {
        url = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("ApexSpeed", isDirectory: true).appendingPathComponent("history.json")
    }
    func load() throws -> HistoryArchive {
        guard FileManager.default.fileExists(atPath: url.path) else { return HistoryArchive() }
        return try JSONDecoder().decode(HistoryArchive.self, from: Data(contentsOf: url))
    }
    func save(_ archive: HistoryArchive) throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(archive).write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
}
