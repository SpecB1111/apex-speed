import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var tracker: TrackingStore
    @Environment(\.dismiss) private var dismiss
    @State private var value = ""
    @State private var unit: SpeedUnit = .kmh
    private var candidate: SpeedTarget? {
        guard let number = Int(value), (10...300).contains(number) else { return nil }
        let target = SpeedTarget(value: number, unit: unit)
        return tracker.targets.contains(target) ? nil : target
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("Display") {
                    Picker("Speed unit", selection: $tracker.unit) {
                        ForEach(SpeedUnit.allCases) { Text($0.label).tag($0) }
                    }
                }
                Section(content: {
                    ForEach(SpeedTarget.defaults) { Text($0.label) }
                    ForEach(tracker.customTargets) { Text($0.label) }
                        .onDelete { offsets in tracker.customTargets.remove(atOffsets: offsets) }
                        .deleteDisabled(tracker.running)
                    HStack {
                        TextField("Target (10–300)", text: $value).keyboardType(.numberPad)
                            .accessibilityLabel("Custom target speed")
                        Picker("Target unit", selection: $unit) {
                            ForEach(SpeedUnit.allCases) { Text($0.label).tag($0) }
                        }.labelsHidden()
                    }
                    Button("Add target") {
                        if let candidate { tracker.customTargets.append(candidate); value = "" }
                    }.disabled(candidate == nil || tracker.running || tracker.customTargets.count >= 8)
                }, header: { Text("Acceleration targets") }, footer: {
                    Text("Up to 8 custom targets. Stop tracking before changing targets. Standard targets keep their original units regardless of your speed display preference.")
                })

                Section("How timing works") {
                    Text("Hold still for at least 2 seconds with a strong GPS signal. Timing arms automatically and starts from the last stationary GPS fix once movement is confirmed. Slow launches, signal gaps, or weak fixes reset timing.")
                    Text("Crossings are interpolated between GPS fixes. Times are estimates shown to 0.1 seconds; that is display precision, not guaranteed accuracy. There is no 1-foot rollout. A new run requires another complete stop.")
                }
                Section("Dynamic Island & background") {
                    Text("Leaving the app keeps an active tracking session running with the location indicator. Tap Stop & Save here or Stop in the Live Activity to end it.")
                    Text("iOS chooses the Island’s visibility and refresh rate. Old readings are replaced with a dash when the activity becomes stale. Swiping the app away can leave its last activity visible until iOS removes it; reopen Apex Speed to clean it up.")
                    Text("Sessions are limited to 7 hours 54 minutes while the app can run. GPS may be interrupted by iOS, low power conditions, or poor reception. No background restart is attempted after termination.")
                }
                Section("Privacy") {
                    Text("No account, ads, analytics, server, or AI service. Session statistics stay in this app’s local storage and may be included in your device backup. Coordinates and routes are not stored. Delete a saved session by swiping it in History.")
                }
                Section {
                    Text("Use only where lawful. Acceleration tests belong on closed courses. Never handle the phone while driving. This app is not a certified speed or performance measuring instrument.")
                }
            }.navigationTitle("Settings")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}
