import SwiftUI

enum ApexTheme {
    static let accent = Color(red: 1, green: 0.24, blue: 0.3)
    static let background = Color(red: 0.035, green: 0.045, blue: 0.065)
    static let panel = Color(red: 0.075, green: 0.09, blue: 0.115)
}

struct DashboardView: View {
    @EnvironmentObject private var tracker: TrackingStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("acceptedClosedCourse") private var accepted = false
    @State private var showSafety = false
    @State private var showSettings = false
    @State private var showHistory = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("VØRIX").font(.system(size: 30, weight: .black, design: .rounded)).tracking(4)
                            Text("R I D E  / /  0 1").font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button { showHistory = true } label: { Image(systemName: "clock.arrow.circlepath").padding(12).background(ApexTheme.panel, in: Circle()) }
                            .accessibilityLabel("Session history")
                        Button { showSettings = true } label: { Image(systemName: "slider.horizontal.3").padding(12).background(ApexTheme.panel, in: Circle()) }
                            .accessibilityLabel("Settings")
                    }
                    HStack(spacing: 7) {
                        Circle().fill(tracker.gpsQuality == .strong ? ApexTheme.accent : Color.orange).frame(width: 6, height: 6)
                        Text(tracker.status).font(.caption.weight(.medium))
                    }.foregroundStyle(.secondary)

                    SpeedDial(speed: tracker.speed.map(tracker.unit.display), unit: tracker.unit.label,
                              approximate: tracker.gpsQuality == .limited)
                        .frame(height: 265)
                        .animation(reduceMotion ? nil : .easeOut(duration: 0.2), value: tracker.speed)

                    if tracker.running {
                        VStack(spacing: 6) {
                            Text("AUTO GPS").font(.caption2.weight(.bold)).tracking(2)
                            if let position = tracker.positionAccuracy, let accuracy = tracker.accuracy {
                                Text(String(format: "Position ±%.1f m · Raw speed ±%.1f %@",
                                            position, tracker.unit.display(accuracy), tracker.unit.label))
                                    .font(.caption.monospacedDigit()).multilineTextAlignment(.center)
                                Text("Phone-reported estimates · lower is better")
                                    .font(.caption2).foregroundStyle(.secondary)
                            } else {
                                Text("Waiting for a fresh measurement").font(.caption).foregroundStyle(.secondary)
                            }
                        }.frame(maxWidth: .infinity).padding(14)
                            .background(ApexTheme.panel, in: RoundedRectangle(cornerRadius: 16))
                    }

                    Picker("Speed units", selection: $tracker.unit) {
                        ForEach(SpeedUnit.allCases) { Text($0.label).tag($0) }
                    }.pickerStyle(.segmented).frame(maxWidth: 230)

                    HStack(spacing: 10) {
                        MetricTile(title: "MAX SPEED", value: String(format: "%.0f", tracker.unit.display(tracker.active?.maxSpeed ?? 0)), suffix: tracker.unit.label)
                        MetricTile(title: "DISTANCE", value: tracker.distanceText, suffix: "GPS estimate")
                    }
                    if let session = tracker.active {
                        TimelineView(.periodic(from: .now, by: 1)) { context in
                            HStack {
                                Label(durationText(context.date.timeIntervalSince(session.started)), systemImage: "timer")
                                Spacer()
                                Text(String(format: "AVG %.0f %@", tracker.unit.display(session.averageSpeed), tracker.unit.label))
                            }.font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        }
                    }
                    LeanPanel().environmentObject(tracker)

                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text("LAUNCH CONTROL").font(.caption.weight(.bold)).tracking(2)
                            Spacer()
                            Image(systemName: "flag.checkered").foregroundStyle(ApexTheme.accent)
                        }
                        Text(tracker.timingStatus).font(.subheadline).foregroundStyle(ApexTheme.accent)
                        ForEach(tracker.targets) { target in
                            HStack {
                                Text(target.label).font(.subheadline.weight(.semibold))
                                Spacer()
                                VStack(alignment: .trailing, spacing: 3) {
                                    let current = tracker.currentSplits.first { $0.target.id == target.id }?.seconds
                                        ?? tracker.active?.runs.last?.splits.first { $0.target.id == target.id }?.seconds
                                    Text(current.map { String(format: "%.1f s", $0) } ?? "—")
                                        .font(.title3.weight(.semibold).monospacedDigit())
                                    Text(tracker.best(for: target).map { String(format: "BEST %.1f s", $0) } ?? "NO RUNS YET")
                                        .font(.system(size: 10, weight: .medium)).foregroundStyle(.secondary)
                                }
                            }
                            if target != tracker.targets.last { Divider().overlay(Color.white.opacity(0.04)) }
                        }
                        Text("GPS estimates · no rollout deduction").font(.caption2).foregroundStyle(.secondary)
                    }.padding(20).background(ApexTheme.panel, in: RoundedRectangle(cornerRadius: 24))

                    Text("Acceleration testing is for legal, closed courses only. Set up while parked and keep your attention on driving.")
                        .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }.padding(24)
            }
            .background(ApexTheme.background)
            .safeAreaInset(edge: .bottom) {
                Button {
                    if tracker.running { Task { await tracker.stop() } }
                    else if accepted { tracker.start() }
                    else { showSafety = true }
                } label: {
                    HStack {
                        Image(systemName: tracker.running ? "stop.fill" : "location.fill")
                        Text(tracker.stopping ? "SAVING SESSION" : tracker.running ? "STOP & SAVE" : "START SESSION").tracking(1.5)
                    }.font(.subheadline.weight(.heavy)).frame(maxWidth: .infinity).padding(20)
                }
                .foregroundStyle(tracker.running ? Color.white : Color.black)
                .background(tracker.running ? Color.red.opacity(0.75) : ApexTheme.accent, in: RoundedRectangle(cornerRadius: 20))
                .disabled(!tracker.ready || tracker.stopping)
                .padding(.horizontal, 24).padding(.vertical, 12).background(.ultraThinMaterial)
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) { SettingsView().environmentObject(tracker) }
            .sheet(isPresented: $showHistory) { HistoryView().environmentObject(tracker) }
            .alert("Before you start", isPresented: $showSafety) {
                Button("I understand") { accepted = true; tracker.start() }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("Use acceleration timers only on a legal closed course. Mount the phone and configure it while parked. GPS estimates are not certified timing or a substitute for your vehicle’s speedometer. Background tracking uses battery. Stop the session to end tracking and remove the Island display.")
            }
            .alert("VØRIX Ride", isPresented: Binding(get: { tracker.message != nil }, set: { if !$0 { tracker.message = nil } })) {
                Button("OK") { tracker.message = nil }
                Button("Open Settings") {
                    if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                }
            } message: { Text(tracker.message ?? "") }
        }
    }
}

struct SpeedDial: View {
    var speed: Double?
    var unit: String
    var approximate = false
    private var fraction: Double { min(1, max(0, (speed ?? 0) / (unit == "mph" ? 180 : 300))) }
    var body: some View {
        ZStack {
            Circle().trim(from: 0.13, to: 0.87).stroke(Color.white.opacity(0.07), style: StrokeStyle(lineWidth: 9, lineCap: .round))
                .rotationEffect(.degrees(90))
            Circle().trim(from: 0.13, to: 0.13 + 0.74 * fraction)
                .stroke(ApexTheme.accent.gradient, style: StrokeStyle(lineWidth: 9, lineCap: .round))
                .rotationEffect(.degrees(90)).shadow(color: ApexTheme.accent.opacity(0.28), radius: 10)
            VStack(spacing: 0) {
                Text(approximate ? "APPROXIMATE SPEED" : "LIVE SPEED").font(.system(size: 10, weight: .bold)).tracking(2).foregroundStyle(approximate ? Color.orange : Color.gray)
                Text(speed.map { String(format: "%.0f", $0) } ?? "—")
                    .font(.system(size: 88, weight: .thin, design: .rounded)).monospacedDigit()
                    .contentTransition(.numericText()).minimumScaleFactor(0.5).lineLimit(1)
                Text(unit).font(.subheadline.weight(.medium)).foregroundStyle(ApexTheme.accent)
            }.padding(28)
        }.padding(10).frame(maxWidth: 300)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(speed.map { "\(approximate ? "Approximate speed" : "Speed") \(Int($0.rounded())) \(unit)" } ?? "Waiting for GPS speed")
    }
}

struct MetricTile: View {
    var title: String
    var value: String
    var suffix: String
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.system(size: 9, weight: .bold)).tracking(1.3).foregroundStyle(.secondary)
            Text(value).font(.title2.weight(.medium).monospacedDigit()).minimumScaleFactor(0.6).lineLimit(1)
            Text(suffix).font(.caption2).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(17)
            .background(ApexTheme.panel, in: RoundedRectangle(cornerRadius: 20))
    }
}

func durationText(_ seconds: Double) -> String {
    let total = max(0, Int(seconds))
    return String(format: "%02d:%02d:%02d", total / 3600, total / 60 % 60, total % 60)
}
