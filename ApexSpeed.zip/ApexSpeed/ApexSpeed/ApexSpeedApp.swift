import SwiftUI

@main
struct ApexSpeedApp: App {
    @StateObject private var tracker = TrackingStore.shared
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            DashboardView()
                .environmentObject(tracker)
                .preferredColorScheme(.dark)
                .tint(ApexTheme.accent)
                .onChange(of: phase) { _, newPhase in tracker.sceneChanged(newPhase) }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.willTerminateNotification)) { _ in
                    tracker.persist()
                    Task { await tracker.stop() }
                }
                .onOpenURL { _ in tracker.checkFreshness() }
        }
    }
}
