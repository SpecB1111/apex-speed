import SwiftUI
import CoreLocation
import UIKit

@MainActor
final class TrackingStore: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = TrackingStore()
    @Published private(set) var active: SessionRecord?
    @Published private(set) var sessions: [SessionRecord] = []
    @Published private(set) var speed: Double?
    @Published private(set) var accuracy: Double?
    @Published private(set) var positionAccuracy: Double?
    @Published private(set) var gpsQuality: GPSQuality = .unavailable
    @Published private(set) var status = "Ready for your next session"
    @Published private(set) var timingStatus = "Come to a complete stop"
    @Published private(set) var currentSplits: [Split] = []
    @Published private(set) var ready = false
    @Published private(set) var stopping = false
    @Published var message: String?
    @Published var unit: SpeedUnit = .kmh {
        didSet { UserDefaults.standard.set(unit.rawValue, forKey: "speedUnit"); publishActivity(force: true) }
    }
    @Published var customTargets: [SpeedTarget] = [] {
        didSet { UserDefaults.standard.set(try? JSONEncoder().encode(customTargets), forKey: "customTargets") }
    }
    var targets: [SpeedTarget] { SpeedTarget.defaults + customTargets }
    var running: Bool { active != nil }
    var distanceText: String {
        let distance = active?.distance ?? 0
        return String(format: "%.2f %@", distance / (unit == .kmh ? 1000 : 1609.344), unit == .kmh ? "km" : "mi")
    }

    private let manager = CLLocationManager()
    private let live = LiveActivityController()
    private let repository = HistoryRepository()
    private var writable = true
    private var engine = AccelerationEngine(targets: SpeedTarget.defaults)
    private var trip = TripAccumulator()
    private var speedDisplay = AdaptiveSpeedDisplay()
    private var lastFix: Date?
    private var lastProcessed: Date?
    private var lastSave = Date.distantPast
    private var watchdog: Timer?
    private var awaitingPermission = false

    private override init() {
        super.init()
        unit = SpeedUnit(rawValue: UserDefaults.standard.string(forKey: "speedUnit") ?? "") ?? .kmh
        if let data = UserDefaults.standard.data(forKey: "customTargets"),
           let saved = try? JSONDecoder().decode([SpeedTarget].self, from: data) {
            customTargets = Array(Set(saved.filter { (10...300).contains($0.value) && !SpeedTarget.defaults.contains($0) })).prefix(8).map { $0 }
        }
        do {
            let archive = try repository.load()
            sessions = archive.sessions
            if var recovered = archive.active {
                recovered.ended = recovered.updated; recovered.interrupted = true
                sessions.insert(recovered, at: 0)
                status = "Previous session recovered after interruption"
                persist()
            }
        } catch {
            writable = false
            message = "History could not be read. The original file is preserved. Tracking is disabled until this is resolved: \(error.localizedDescription)"
        }
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        manager.distanceFilter = kCLDistanceFilterNone
        manager.activityType = .automotiveNavigation
        manager.pausesLocationUpdatesAutomatically = false
        manager.showsBackgroundLocationIndicator = true
        Task { await live.clearOrphans(); ready = true }
    }

    func start() {
        guard ready, !running, !stopping else { return }
        guard writable else {
            message = "History could not be read. Back up the app container using Xcode before repairing or reinstalling; the original history has been preserved."
            return
        }
        guard UIApplication.shared.applicationState == .active else { return }
        switch manager.authorizationStatus {
        case .notDetermined:
            awaitingPermission = true
            manager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse:
            guard manager.accuracyAuthorization == .fullAccuracy else {
                message = "Enable Precise Location in Settings → VØRIX Ride → Location, then start again."
                return
            }
            beginSession()
        case .denied, .restricted:
            message = "Location access is off. In Settings → VØRIX Ride → Location, choose While Using the App and enable Precise Location."
        @unknown default: message = "Location authorization is unavailable."
        }
    }

    private func beginSession() {
        let now = Date()
        active = SessionRecord(started: now, updated: now)
        speed = nil; accuracy = nil; lastFix = nil; lastProcessed = nil
        positionAccuracy = nil; gpsQuality = .unavailable; speedDisplay.reset()
        engine = AccelerationEngine(targets: targets); trip = TripAccumulator(); currentSplits = []
        status = "Acquiring GPS"; timingStatus = engine.phase
        persist()
        if let record = active, let activityMessage = live.start(record: record, state: activityState()) {
            message = activityMessage
        }
        manager.allowsBackgroundLocationUpdates = true
        manager.startUpdatingLocation()
        watchdog = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.checkFreshness() }
        }
    }

    func stop() async {
        guard !stopping else { return }
        stopping = true
        awaitingPermission = false
        manager.stopUpdatingLocation(); manager.allowsBackgroundLocationUpdates = false
        watchdog?.invalidate(); watchdog = nil
        if let lastFix, Date().timeIntervalSince(lastFix) > 3 { engine.invalidate() }
        if var record = active {
            if let run = engine.finish() { record.runs.append(run) }
            record.ended = Date(); record.updated = Date()
            sessions.insert(record, at: 0)
        }
        active = nil; speed = nil; accuracy = nil; currentSplits = []
        positionAccuracy = nil; gpsQuality = .unavailable; speedDisplay.reset()
        status = "Session saved"; timingStatus = "Come to a complete stop"
        persist()
        await live.end()
        stopping = false
    }

    func checkFreshness() {
        guard let active else { return }
        if Date().timeIntervalSince(active.started) >= 7.9 * 3600 {
            message = "This session reached its duration limit. Start another session when ready."
            Task { await stop() }; return
        }
        if let lastFix, Date().timeIntervalSince(lastFix) > 3 {
            invalidateFix("GPS signal lost")
        }
    }

    private func invalidateFix(_ reason: String) {
        speed = nil; accuracy = nil; status = reason
        positionAccuracy = nil; gpsQuality = .unavailable; speedDisplay.reset()
        engine.invalidate(); trip.breakContinuity()
        timingStatus = engine.phase; currentSplits = []
        publishActivity(force: true)
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let allowed = manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways
        if running && (!allowed || manager.accuracyAuthorization != .fullAccuracy) {
            message = "Tracking stopped because precise location permission changed."
            Task { await stop() }
        } else if awaitingPermission && manager.authorizationStatus != .notDetermined {
            awaitingPermission = false
            if allowed {
                // The prompt can briefly leave the app inactive; the visible start button remains available.
                start()
            } else { message = "Location permission is needed to measure speed." }
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard running, !stopping else { return }
        for location in locations.sorted(by: { $0.timestamp < $1.timestamp }) {
            guard let started = active?.started, location.timestamp >= started else { continue }
            if let lastProcessed, location.timestamp <= lastProcessed { continue }
            let sample = SpeedSample(time: location.timestamp, speed: location.speed,
                                     horizontalAccuracy: location.horizontalAccuracy, speedAccuracy: location.speedAccuracy)
            lastProcessed = location.timestamp
            let now = Date()
            let quality = sample.displayQuality(at: now)
            guard quality != .unavailable else { invalidateFix("Waiting for an accurate GPS fix"); continue }
            let qualityChanged = gpsQuality != quality
            lastFix = sample.time
            speed = speedDisplay.consume(sample, at: now)
            accuracy = sample.speedAccuracy; positionAccuracy = sample.horizontalAccuracy
            gpsQuality = quality; status = quality.label
            if var record = active {
                // Limited-quality readings may help the display but must not inflate records.
                if sample.usable(at: now) { trip.consume(sample, record: &record) }
                else { trip.breakContinuity() }
                let completed = engine.consume(sample)
                if let completed { record.runs.append(completed) }
                active = record
                timingStatus = engine.phase; currentSplits = engine.splits
                if completed != nil || Date().timeIntervalSince(lastSave) >= 5 { persist() }
            }
            publishActivity(force: qualityChanged)
        }
        checkFreshness()
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        guard running else { return }
        invalidateFix("GPS unavailable")
        if (error as? CLError)?.code == .denied {
            message = "Location services became unavailable."
            Task { await stop() }
        }
    }

    func sceneChanged(_ phase: ScenePhase) {
        if phase == .active { checkFreshness() }
        if phase == .background { persist() }
    }

    func persist() {
        guard writable else { return }
        do { try repository.save(HistoryArchive(sessions: sessions, active: active)); lastSave = Date() }
        catch { message = "Could not save history: \(error.localizedDescription). Keep the app open and free some device storage." }
    }

    func deleteSessions(at offsets: IndexSet) { sessions.remove(atOffsets: offsets); persist() }
    func recordLean(_ degrees: Double) {
        guard degrees.isFinite, abs(degrees) <= 90, var record = active else { return }
        let left = max(0, -degrees), right = max(0, degrees)
        if record.maxLeanLeft == nil || left > (record.maxLeanLeft ?? 0) + 0.5 || right > (record.maxLeanRight ?? 0) + 0.5 {
            record.maxLeanLeft = max(record.maxLeanLeft ?? 0, left)
            record.maxLeanRight = max(record.maxLeanRight ?? 0, right)
            active = record
        }
    }
    func best(for target: SpeedTarget) -> Double? {
        (sessions + (active.map { [$0] } ?? [])).flatMap(\.runs).flatMap(\.splits)
            .filter { $0.target.id == target.id }.map(\.seconds).min()
    }

    private func activityState() -> SpeedActivityAttributes.ContentState {
        .init(speed: speed.map { Int(unit.display($0).rounded()) }, unit: unit.label,
              maxSpeed: Int(unit.display(active?.maxSpeed ?? 0).rounded()), distance: distanceText,
              status: gpsQuality == .strong ? timingStatus : status, updated: lastFix ?? Date(),
              approximate: gpsQuality == .limited)
    }
    private func publishActivity(force: Bool = false) {
        guard running else { return }
        live.update(activityState(), force: force)
    }
}
