import SwiftUI

struct HistoryView: View {
    @EnvironmentObject private var tracker: TrackingStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                if tracker.sessions.isEmpty {
                    ContentUnavailableView("Your next run starts here", systemImage: "flag.checkered", description: Text("Stop a tracking session to save its stats and completed acceleration splits."))
                } else {
                    Section("Personal bests · GPS estimates") {
                        ForEach(tracker.targets) { target in
                            LabeledContent(target.label, value: tracker.best(for: target).map { String(format: "%.1f s", $0) } ?? "—")
                        }
                    }
                    Section("Sessions · swipe to delete") {
                        ForEach(tracker.sessions) { session in
                            NavigationLink {
                                SessionDetailView(session: session, unit: tracker.unit)
                            } label: {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(session.started.formatted(date: .abbreviated, time: .shortened)).font(.headline)
                                    Text("\(durationText(session.duration)) · \(session.runs.count) runs\(session.interrupted ? " · interrupted" : "")")
                                        .font(.caption).foregroundStyle(.secondary)
                                }.padding(.vertical, 5)
                            }
                        }.onDelete(perform: tracker.deleteSessions)
                    }
                }
            }.navigationTitle("History")
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}

struct SessionDetailView: View {
    let session: SessionRecord
    let unit: SpeedUnit
    var body: some View {
        List {
            Section("Session") {
                LabeledContent("Started", value: session.started.formatted(date: .abbreviated, time: .shortened))
                LabeledContent("Duration", value: durationText(session.duration))
                LabeledContent("Measured time", value: durationText(session.measuredSeconds))
                LabeledContent("Moving time", value: durationText(session.movingSeconds))
                LabeledContent("Distance", value: String(format: "%.2f %@", session.distance / (unit == .kmh ? 1000 : 1609.344), unit == .kmh ? "km" : "mi"))
                LabeledContent("Maximum", value: String(format: "%.0f %@", unit.display(session.maxSpeed), unit.label))
                LabeledContent("Average", value: String(format: "%.0f %@", unit.display(session.averageSpeed), unit.label))
                if session.interrupted { Text("Recovered to the last saved checkpoint. Unsaved data and the in-progress run were discarded.").foregroundStyle(.orange) }
            }
            ForEach(session.runs) { run in
                Section("Run · \(run.started.formatted(date: .omitted, time: .standard))") {
                    ForEach(run.splits) { split in
                        LabeledContent(split.target.label, value: String(format: "%.1f s", split.seconds))
                    }
                    Text(String(format: "Longest fix interval %.2f s · worst reported speed uncertainty ±%.1f m/s", run.maxSampleGap, run.worstSpeedAccuracy))
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            Section {
                Text("Distance integrates valid GPS speeds. Missing intervals are excluded from distance and average; measured time shows the coverage. Partial runs include only targets actually crossed before stopping.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle("Session details")
    }
}
